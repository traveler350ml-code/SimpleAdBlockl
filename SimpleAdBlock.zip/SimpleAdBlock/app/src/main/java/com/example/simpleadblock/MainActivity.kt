package com.example.simpleadblock

import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts

class MainActivity : ComponentActivity() {

    private lateinit var status: TextView
    private lateinit var stats: TextView
    private lateinit var button: Button
    private val handler = Handler(Looper.getMainLooper())

    private val vpnPermission =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            if (r.resultCode == RESULT_OK) startVpnService()
        }

    private val refresh = object : Runnable {
        override fun run() {
            val on = AdBlockVpnService.running
            status.text = if (on) "Perlindungan AKTIF" else "Perlindungan MATI"
            button.text = if (on) "Matikan" else "Aktifkan"
            stats.text = "Diblokir: ${AdBlockVpnService.blockedCount.get()} " +
                "dari ${AdBlockVpnService.totalCount.get()} query DNS"
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (24 * resources.displayMetrics.density).toInt()

        status = TextView(this).apply { textSize = 24f; gravity = Gravity.CENTER }
        stats = TextView(this).apply { textSize = 16f; gravity = Gravity.CENTER; setPadding(0, pad, 0, pad) }
        button = Button(this).apply { setOnClickListener { toggle() } }

        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(pad, pad, pad, pad)
            addView(status)
            addView(stats)
            addView(button)
        })
    }

    override fun onResume() { super.onResume(); handler.post(refresh) }
    override fun onPause() { super.onPause(); handler.removeCallbacks(refresh) }

    private fun toggle() {
        if (AdBlockVpnService.running) {
            startService(Intent(this, AdBlockVpnService::class.java).setAction(AdBlockVpnService.ACTION_STOP))
        } else {
            val intent = VpnService.prepare(this)
            if (intent != null) vpnPermission.launch(intent) else startVpnService()
        }
    }

    private fun startVpnService() {
        startService(Intent(this, AdBlockVpnService::class.java).setAction(AdBlockVpnService.ACTION_START))
    }
}
