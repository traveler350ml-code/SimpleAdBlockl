package com.example.simpleadblock

import android.content.Intent
import android.net.VpnService
import android.os.ParcelFileDescriptor
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger

/**
 * VPN lokal yang HANYA menangkap lalu lintas DNS (rute /32 ke server DNS palsu).
 * Query untuk domain iklan dijawab NXDOMAIN, sisanya diteruskan ke DNS upstream.
 */
class AdBlockVpnService : VpnService() {

    companion object {
        const val ACTION_START = "com.example.simpleadblock.START"
        const val ACTION_STOP = "com.example.simpleadblock.STOP"
        private const val VPN_ADDRESS = "10.111.222.1"
        private const val FAKE_DNS = "10.111.222.2"
        private const val UPSTREAM_DNS = "1.1.1.1"

        @Volatile var running = false
        val blockedCount = AtomicInteger(0)
        val totalCount = AtomicInteger(0)
    }

    private var tun: ParcelFileDescriptor? = null
    private var worker: Thread? = null
    private val pool = Executors.newCachedThreadPool()
    private lateinit var blocklist: Blocklist

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopVpn()
            return START_NOT_STICKY
        }
        startVpn()
        return START_STICKY
    }

    private fun startVpn() {
        if (running) return
        blocklist = Blocklist(this)
        tun = Builder()
            .setSession("Simple AdBlock")
            .addAddress(VPN_ADDRESS, 32)
            .addDnsServer(FAKE_DNS)
            .addRoute(FAKE_DNS, 32)
            .setBlocking(true)
            .establish() ?: return
        running = true
        blockedCount.set(0)
        totalCount.set(0)
        worker = Thread({ loop(tun!!) }, "dns-loop").also { it.start() }
    }

    private fun stopVpn() {
        running = false
        worker?.interrupt()
        try { tun?.close() } catch (_: Exception) {}
        tun = null
        stopSelf()
    }

    override fun onDestroy() {
        stopVpn()
        pool.shutdownNow()
        super.onDestroy()
    }

    override fun onRevoke() {
        stopVpn()
        super.onRevoke()
    }

    private fun loop(pfd: ParcelFileDescriptor) {
        val input = FileInputStream(pfd.fileDescriptor)
        val output = FileOutputStream(pfd.fileDescriptor)
        val buf = ByteArray(32767)
        try {
            while (running) {
                val len = input.read(buf)
                if (len <= 0) continue
                val packet = buf.copyOf(len)
                pool.execute { handlePacket(packet, output) }
            }
        } catch (_: Exception) {
        } finally {
            running = false
        }
    }

    private fun handlePacket(p: ByteArray, out: FileOutputStream) {
        try {
            if (p.size < 28 || (p[0].toInt() shr 4) != 4) return        // hanya IPv4
            val ihl = (p[0].toInt() and 0x0F) * 4
            if (p[9].toInt() != 17) return                                // hanya UDP
            val srcPort = u16(p, ihl)
            val dstPort = u16(p, ihl + 2)
            if (dstPort != 53) return
            val udpLen = u16(p, ihl + 4)
            val dns = p.copyOfRange(ihl + 8, minOf(p.size, ihl + udpLen))

            val name = parseQName(dns) ?: return
            totalCount.incrementAndGet()

            val reply: ByteArray = if (blocklist.isBlocked(name)) {
                blockedCount.incrementAndGet()
                buildNxDomain(dns)
            } else {
                forward(dns) ?: return
            }

            val srcIp = p.copyOfRange(12, 16)
            val dstIp = p.copyOfRange(16, 20)
            val resp = buildIpUdp(dstIp, srcIp, 53, srcPort, reply)
            synchronized(out) { out.write(resp) }
        } catch (_: Exception) {
        }
    }

    private fun forward(query: ByteArray): ByteArray? {
        DatagramSocket().use { s ->
            protect(s) // supaya tidak masuk lagi ke VPN
            s.soTimeout = 4000
            val addr = InetAddress.getByName(UPSTREAM_DNS)
            s.send(DatagramPacket(query, query.size, addr, 53))
            val rb = ByteArray(4096)
            val rp = DatagramPacket(rb, rb.size)
            s.receive(rp)
            return rb.copyOf(rp.length)
        }
    }

    // ---------- Helper DNS ----------

    private fun parseQName(dns: ByteArray): String? {
        if (dns.size < 13) return null
        var i = 12
        val sb = StringBuilder()
        while (i < dns.size) {
            val l = dns[i].toInt() and 0xFF
            if (l == 0) break
            if (l and 0xC0 != 0 || i + 1 + l > dns.size) return null
            if (sb.isNotEmpty()) sb.append('.')
            sb.append(String(dns, i + 1, l, Charsets.US_ASCII))
            i += l + 1
        }
        return sb.toString()
    }

    private fun buildNxDomain(q: ByteArray): ByteArray {
        var i = 12
        while (i < q.size && q[i].toInt() != 0) i += (q[i].toInt() and 0xFF) + 1
        val end = minOf(q.size, i + 1 + 4) // akhir bagian question (null + QTYPE + QCLASS)
        val r = q.copyOf(end)
        r[2] = 0x81.toByte()  // QR=1, RD=1
        r[3] = 0x83.toByte()  // RA=1, RCODE=3 (NXDOMAIN)
        r[6] = 0; r[7] = 0    // ANCOUNT
        r[8] = 0; r[9] = 0    // NSCOUNT
        r[10] = 0; r[11] = 0  // ARCOUNT
        return r
    }

    // ---------- Helper IP/UDP ----------

    private fun u16(b: ByteArray, o: Int) = ((b[o].toInt() and 0xFF) shl 8) or (b[o + 1].toInt() and 0xFF)

    private fun buildIpUdp(src: ByteArray, dst: ByteArray, sp: Int, dp: Int, payload: ByteArray): ByteArray {
        val total = 20 + 8 + payload.size
        val b = ByteArray(total)
        b[0] = 0x45; b[1] = 0
        b[2] = (total shr 8).toByte(); b[3] = total.toByte()
        b[6] = 0x40; b[7] = 0       // Don't Fragment
        b[8] = 64; b[9] = 17        // TTL, UDP
        System.arraycopy(src, 0, b, 12, 4)
        System.arraycopy(dst, 0, b, 16, 4)
        val ck = checksum(b, 0, 20)
        b[10] = (ck shr 8).toByte(); b[11] = ck.toByte()
        b[20] = (sp shr 8).toByte(); b[21] = sp.toByte()
        b[22] = (dp shr 8).toByte(); b[23] = dp.toByte()
        val ul = 8 + payload.size
        b[24] = (ul shr 8).toByte(); b[25] = ul.toByte()
        // checksum UDP = 0 (diperbolehkan di IPv4)
        System.arraycopy(payload, 0, b, 28, payload.size)
        return b
    }

    private fun checksum(b: ByteArray, off: Int, len: Int): Int {
        var sum = 0L
        var i = off
        while (i < off + len) {
            sum += ((b[i].toInt() and 0xFF) shl 8) or (b[i + 1].toInt() and 0xFF)
            i += 2
        }
        while (sum shr 16 != 0L) sum = (sum and 0xFFFF) + (sum shr 16)
        return (sum.inv() and 0xFFFF).toInt()
    }
}
