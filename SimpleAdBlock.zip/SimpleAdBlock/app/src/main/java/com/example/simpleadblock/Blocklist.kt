package com.example.simpleadblock

import android.content.Context

class Blocklist(context: Context) {
    private val domains = HashSet<String>()

    init {
        context.assets.open("blocklist.txt").bufferedReader().useLines { lines ->
            for (raw in lines) {
                val line = raw.substringBefore('#').trim().lowercase()
                if (line.isEmpty()) continue
                // Mendukung format hosts: "0.0.0.0 example.com"
                val domain = line.split(Regex("\\s+")).last()
                if (domain != "localhost") domains.add(domain)
            }
        }
    }

    /** True jika domain atau salah satu domain induknya ada di daftar. */
    fun isBlocked(name: String): Boolean {
        var d = name.lowercase().trimEnd('.')
        while (true) {
            if (d in domains) return true
            val dot = d.indexOf('.')
            if (dot < 0) return false
            d = d.substring(dot + 1)
        }
    }
}
