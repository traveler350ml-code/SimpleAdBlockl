# Simple AdBlock (DNS/VPN)

Cara build:
1. Buka folder ini di Android Studio (Koala atau lebih baru), tunggu Gradle sync.
2. Hubungkan HP (USB debugging) lalu Run, atau Build > Build APK(s).
3. APK ada di app/build/outputs/apk/debug/app-debug.apk

Cara kerja: VPN lokal hanya merutekan lalu lintas DNS. Domain di
app/src/main/assets/blocklist.txt dijawab NXDOMAIN, sisanya diteruskan ke 1.1.1.1.
Edit blocklist.txt untuk menambah domain. Hanya IPv4; tidak memblokir iklan
yang memakai DNS-over-HTTPS bawaan aplikasi.
